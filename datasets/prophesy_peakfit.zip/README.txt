PROPHESY peak-fitting dataset, schema prophesy_peakfit_v1.
Each NPZ holds one spectral region and a common binding-energy grid.
noisy_counts is the measured-like input; clean_counts is the noise-free
peak signal without background. peak_sigma_eV is Gaussian sigma, not FWHM.
C1s/S2p peak_fraction is the generator's cross-section mixture weight;
peak_area_counts_eV follows the repository's fraction × total-area rule.
O1s fractions and areas come from the separately saved liquid and gas
signals. Its common measured grid is 528–542 eV. The ZIP contains
primary and repeated noisy scans; repeats share condition labels.
Keep all scans from a workbook in one data split. Experimental fitting
tables and older unlabeled simulations are excluded.
